<?php

    new hook("casinoMenu", function () {
        return array(
            "url" => "?page=blackjack", 
            "text" => "Blackjack"
        );
    });
