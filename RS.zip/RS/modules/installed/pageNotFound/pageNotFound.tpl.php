<?php

    class pageNotFoundTemplate extends template {
        
        public $pageNotFound = '

            <div class="panel panel-default">
                <div class="panel-heading">Something went wrong</div>
                <div class="panel-body">
                    <p> We could not find the page you requested!</p>
                </div>
            </div>
        ';
        
    }

