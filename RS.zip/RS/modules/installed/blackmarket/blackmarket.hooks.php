<?php
    new hook("locationMenu", function () {
        return array(
            "url" => "?page=blackmarket", 
            "text" => "Black Market", 
            "sort" => 100
        );
    });
