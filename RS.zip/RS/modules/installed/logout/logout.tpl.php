<?php

    class logoutTemplate extends template {
        
    }

