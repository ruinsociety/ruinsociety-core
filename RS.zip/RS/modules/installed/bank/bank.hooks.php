<?php

    new hook("moneyMenu", function () {
        return array(
            "url" => "?page=bank", 
            "text" => "Bank"
        );
    });
