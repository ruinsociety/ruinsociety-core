<?php

    new hook("killMenu", function () {
        return array(
            "url" => "?page=kill", 
            "text" => "Kill", 
            "sort" => 50
        );
    });

